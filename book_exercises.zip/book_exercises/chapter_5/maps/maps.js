//Maps
const ourMap = new Map();

ourMap.set('one', 1);
ourMap.set('two', 2);
ourMap.set('three', 3);
ourMap.set('four', '4');
ourMap.set('five', '5');
ourMap.set('six', '6');
console.log(ourMap);
//get a value
console.log(ourMap.get('three'));//3
//set new value
ourMap.set('seven',7);
console.log(ourMap);
//get the size of the map
console.log(ourMap.size);//7
//delete an element
console.log(ourMap.delete('seven'));
console.log(ourMap);

//iterate over map using forEach
ourMap.forEach((value,key) => {
    console.log(key, ': ' + value);
});

//WeakMap
// Creating a WeakMap Object
const wMap = new WeakMap();
  
// Adding elements in it 
let obj1 = {} 
wMap.set(obj1, "Obj 1");
let obj2 = {}
wMap.set(obj2, "Obj 2");
  
// delete from WeakMap
wMap.delete(obj2);
  
// Print the WeakMap
console.log(wMap);
// Using get specific element in WeakMap
console.log(wMap.get(obj1));
//check if the element is in the WeakMaP:
console.log(wMap.has(obj1));//true

