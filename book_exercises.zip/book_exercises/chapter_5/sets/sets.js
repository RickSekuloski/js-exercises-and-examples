//Sets
// create Set
const emptySet = new Set(); // create an empty set
console.log(emptySet); // Set {0} {size: 0}

// Set with multiple types of value
const firstSet = new Set([1, 2, 'Hi', {isSet : true}]);
console.log(firstSet); // Set(4) {1, 2, 'Hi' {isSet: true}}

// Set with duplicate values
const secondSet = new Set(['one', 'two', 'three', 'one']);
console.log(secondSet); // Set(3) {'one', 'two', 'three'}


// access the elements of the thirdSet
const thirdSet = new Set([1, 2, 3]);
console.log(thirdSet.values()); // Set Iterator [1, 2, 3]

//adding new elements to thirdSet
//adding new elements
thirdSet.add(4);
console.log(thirdSet.values());//SetIterator {1, 2, 3, 4}

// adding duplicate values will not be added
thirdSet.add(3);
console.log(thirdSet.values());//SetIterator {1, 2, 3, 4}

// check if an element 2 is in the thirdSet
console.log(thirdSet.has(2));//true
console.log(thirdSet.has(5));//false

// removing a particular element like num 2
thirdSet.delete(2);
console.log(thirdSet.values()); // Set Iterator [1, 3, 4]

const fourthSet = new Set([1, 2, 3, 4, 5]);

// looping through Set for-of
for (let i of fourthSet) {
    console.log(i);
}
//same using the forEach loop forEach
fourthSet.forEach(element => {
    console.log(element);
});

//iterate over set using .next() method
const iteratorVal = fourthSet.values();
console.log(iteratorVal.next().value);//1
console.log(iteratorVal.next().value);//2
console.log(iteratorVal.next().value);//3
console.log(iteratorVal.next().value);//4
console.log(iteratorVal.next().value);//5
console.log(iteratorVal.next().value);//undefined

//clean duplicate values in an array
const thisArray = [1,2,3,4,5,6,3,7,8,6,9];
const thisSet = new Set(thisArray);
console.log(thisSet);

//create now unique array from the set
const thisArray1 = Array.from(thisSet);
console.log(thisArray1);

//WeakSet
const weakSet1 = new WeakSet();
console.log(weakSet1); // WeakSet {}

let obj1 = {
    firstName: 'Rick',
    lastName: 'Grimes',
    actor: true,
    citizenship: 'UK'
}

// adding object (element) to WeakSet
weakSet1.add(obj1);

console.log(weakSet1); // WeakSet {{...}}

//add new Objects to a WeakSet
const obj2 = {
    firstName: 'Thomas',
    actor: false
};
//add new object
weakSet1.add(obj2);

//delete an object obj2
weakSet1.delete(obj2);

//look for an element in Set:
console.log(weakSet1.has(obj1)); // true