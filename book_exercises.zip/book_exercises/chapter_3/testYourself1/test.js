//2.1 What is an arrow function, and how we can create one?

//2.2 What will be the correct output from the following code:
const person = {
    firstName: 'Andy',
    age: 10,
    dob:2002,
    nextYear: () => {
        this.dob++; 
    },
}
student.nextYear();
console.log(student.dob);
// e)	2003
// f)	2002
// g)	Undefined
// h)	2001


//2.3 Refactor the following function into ES6 arrow functions
//ES5 syntax
function calculate(arg) { 
    return 10*2;
}
const result = calculate(10);
console.log(result);
//2.4 In the following code change the arg2 and arg3 to have default values of 1.5 and 4 respectively.

function calculateSum2(arg1,arg2,arg3){
    return arg1+arg2+arg3;
}

//After you give the arg2 and arg3 to have default values what will be the output if we console log this code:
console.log(calculateSum2(4.5));

//2.5 What is the correct output:
let x = 2;
function multiply(x,y=12){
    return x * y; 
}
console.log(multiply(5));

// 2.6 Using the template literals combine the following variables to achieve this output:

// ‘My name is Rick Grimes’;

let name = "name";
let is = "is";
let rick = "Rick";
let grimes = "Grimes";
let my = 'My';
let output = '';
//Answer:

//2.7 Refactor the following ES5 string using template literals
let x = 5;
let y = 10;
let z = 15;
let equalSign = '=';
let plusSign = '+';

let finalOutput = x + ' ' + plusSign + ' ' + y + ' ' + equalSign + ' ' + z;

//Answer

//2.8 Write the code to accomplish the following task:
//With the help of destructuring swap the value of the two variables:

let numbers = [4,5];

//2.9 Using the destructuring create three variables that will store the values of the following array:

let stringArray = ['one','two', 'three'];

//Answer
//Expected output:
console.log(one);//one
console.log(two);//two
console.log(three);//three

// 2.10 Which of the following loops was introduced in the ES6
// a) for
// b) for-in 
// c) for-of
// d)while
// e) do-while

// 2.11 What is the correct output of the following code?
let actors = [ "Jonny", "Amber", "Tom","Casper"];
for (let actor of actors){
    console.log(actor);
}
//Answer:
// Jonny
// Amber
// Tom
// Casper

//2.12 Create a new array from the given string and make each letter of that string to be an item in the new array.

let textString = "Hello";

console.log(charArray);// expected output = ["H", "e", "l", "l", "o"]

//2.13 What is the output from the following code?
const numArray = [1,2,3,4,5];
let found = numArray.find( e => e > 3 );
console.log(found);

// 2.14 What is the output from the following code?
const numArray1 = [1,2,3,4,5,3,4,5];
let found1 = numArray1.some( e => e > 3 );
console.log(found1);
// a)true
// b)false

//2.15 What is the output from the following code?
Array.from([1, 2, 3, 4], x => x - 1);
// a) [1,2,3,4]
// b) [0,1,2,3]
// c) [1,1,2,3]

//2.16 Refactor the following code to fit the newer ES6 syntax:

var brand ='Bentley';
var manufactured = 'England';
var color = 'Mat Black';
var engine = 6.75;
var car = {
    brand: brand,
    manufactured: manufactured,
    color: color,
    engine:engine
}

console.log(car.brand);

//2.17  What will be the output from the code below:
let brand ='Bentley';
let manufactured = 'England';
let color = 'Mat Black';
let engine = 6.75;
let transmission = 'automatic';
const car = {
    brand,
    manufactured,
    color,
    engine,
    [transmission]: 'yes'
}

console.log(car.automatic);
// a)	undefined
// b)	yes
// c)	automatic
// d)	transmission


//2.17  What will be the output from the code below:
let brand ='Bentley';
let manufactured = 'England';
let color = 'Mat Black';
let engine = 6.75;
let transmission = 'automatic';
let engineSpeed = 'speed';
const car = {
    brand,
    manufactured,
    color,
    engine,
    [transmission]: 'yes',
    speed,
}

console.log(car.speed);
// a)	undefined
// b)	engineSpeed
// c)	speed
// d)	speed is not defined
// 2.18 What is most accurate description for Symbols
// a) we can use symbols in normal loops
// b) the values they can have can be strings only
// c) the values they produce are unique
// d) they are throwing error when we re-assign them

//2.19 What will the following code produce?

const cars = {
    'BMW': 'Car',
    'Harley-Davidson': 'Motor Bike',
    'Honda': 'Car',
    'BMW': 'Motor Bike',
    'Honda': 'Motor Bike'
}
for (car in cars){
    console.log(car);
}
// a) 
// Car
// Motor Bike
// Car

// b)
// BMW
// Harley-Davidson
// Honda
// BMW

// c)
// BMW
// Harley-Davidson
// Honda

// d)
// Car
// Motor Bike

// e)
// BMW
// Car
// Honda
// Harley-Davidson

//2.20 Rewrite the exercise 2.19 so it will use Symbols to avoid naming collisions and it should print all of the properties as an array
