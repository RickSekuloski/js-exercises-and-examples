//Symbols

let s1 = Symbol();
let actor = Symbol('Rick');
console.log(actor);//Symbol(Rick)
let actor1 = Symbol('Rick');
console.log(actor1);//Symbol(Rick)

console.log(actor == actor1);//false
console.log(actor === actor1);//false


//typeof

console.log(typeof actor);//symbol
//TypeError
//let actor2 = new Symbol('Rick');//TypeError

//Using Symbols to prevent Name Collisions

const cars = {
    'haval': 'car',
    'toyota': 'corola',
    'toyota': 'RAV4'
}
//loop over the brands
for(car in cars){
    console.log(car);
}

//using the symbols
const cars1 = {
    [Symbol('haval')]: 'car',
    [Symbol('toyota')]: 'corola',
    [Symbol('toyota')]: 'RAV4'
}
const symbolProperties = Object.getOwnPropertySymbols(cars1);

//get all properties
console.log(symbolProperties);

const symbolValue = symbolProperties.map(s => cars1[s]);
console.log(symbolValue);