//Array.from()
const names = document.querySelectorAll('.names li');
//collection of nodes known nodelist an array-like collection
console.log(names);

const namesArray = Array.from(names);
console.log(namesArray);//[li, li, li]

//map over the array
const getNames = namesArray.map(name => name.textContent);
console.log(getNames);

//shorter way using the map method as second argument
// const namesArray = Array.from(names, name=>{
//     return name.textContent;
// })
// console.log(namesArray);

//Array.of()
const numbersArray = Array.of(1,2,3,4,5); 
console.log(numbersArray);// [ 1, 2, 3, 4, 5];

//Array.of
const numArray = [1,2,3,4,5,6,7];
let findElement = numbersArray.find(el => el >= 3);
console.log(findElement);

//Array.findIndex()

let findElement1 = numbersArray.findIndex(el => el === 5);
console.log(findElement1);

//array.some and array.every
const numArray1 = [1,2,3,4,5,6,1,2,3,4,5,6,1,1];
let arraySome = numArray1.some( el => el > 3); 
console.log(arraySome);
// true
let arrayEvery = numArray1.every(el => el > 2); 
console.log(arrayEvery);
// false