//Object literals
//ES5 object

var webDev = {
    myName: 'Joseph',
    occupation: 'Web Developer',
    printDetails: function() {
      console.log(`${this.myName} is a ${this.occupation}.`);
    }
  };
  
  webDev.printDetails(); // Joseph is a Web Developer.

//Object Initialization from Variables
//ES5 ex1
var num1 = 2, num2 = 4, num3 = 6;
var obj1 ={
    num1: num1,
    num2: num2,
    num3: num3
};
console.log(obj1);//{num1: 2, num2: 4, num3: 6}

//ES6 ex1
var obj2 ={
    num1,
    num2,
    num3
};
console.log(obj2);//{num1: 2, num2: 4, num3: 6}

//Adding functions/methods to our Objects in ES6

//ES5

var person1 = {
    myName:'Rick Grimes',
    printD:function(){
        return `${this.myName}`;
    }
}
var p1 = person1.printD();
console.log(p1);

//Same example in ES6
let person2 = {
    myName:'Rick Grimes',
    printD(){
        return `${this.myName}`;
    }
}
let p2 = person2.printD();
console.log(p2);

//dynamicaly assign keys
const actor = 'occupation';
let person3 = {
    myName:'Rick Grimes',
    [actor]: 'Actor',
    printD(){
        return `${this.myName}`;
    }
}

console.log(person3);

//Parse the returned object
//ES5
function getObj(){
    const actor1 = {
        name: 'Rick Grimes',
        age: 54
    }
    return actor1;
}

// var actorObj = getObj();
// var name = actorObj.name;
// var age = actorObj.age;
// console.log(name);
// console.log(age);

//ES6
const {name, age} = getObj();
console.log(name);
console.log(age);
