function calculateSum(arg1=1,arg2=2,arg3=3){
    return arg1+arg2+arg3;
}
console.log(calculateSum());

//overriding the default value:
function calculateSum1(arg1=1,arg2=2,arg3=3){
    console.log(arg1);
    console.log(arg2);
    console.log(arg3);
    return arg1+arg2+arg3;
}
console.log(calculateSum1(4));
console.log(calculateSum1(4,6));
console.log(calculateSum1(4,undefined,6));


function calculateSum2(arg1,arg2=1.5,arg3=4){
    return arg1+arg2+arg3;
}
console.log(calculateSum2(4.5));