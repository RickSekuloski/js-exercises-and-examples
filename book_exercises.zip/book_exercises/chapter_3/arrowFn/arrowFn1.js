//get the box with the CSS class selector
// const box = document.querySelector('.box-container');
// //add a event listener
// box.addEventListener('click', function(){
//     //toggle the class 'change' on the div
//     this.classList.toggle('change');
//     //toggle the class after 2 seconds
//     setTimeout(function(){
//         this.classList.toggle('change');
//     },2000);
// });

const box = document.querySelector('.box-container');
//add a event listener
box.addEventListener('click', function(){
    //toggle the class 'change' on the div
    this.classList.toggle('change');
    //toggle the class after 2 seconds
    setTimeout(()=>{
        this.classList.toggle('change');
    },2000);
});

//Avoid using arrow functions 
//Scenario 1
// const submitBtn = document.querySelector(".submit-button"); 
// submitBtn.addEventListener("click", () => {
//     // *this* refers to the 'Window' Object and will throw an error
//     //this.classList.toggle("on"); 
// })

//Scenario 2
const car = { 
    price: 34000,
    increase: function() {
        this.price += 1999;
        console.log(this.price); 
    }
}
car.increase();//35999

//This will not work with arrow functions
const car1 = { 
    price: 34000,
    increase:()=> {
        //this refers to window obj
        this.price += 1000;
        console.log(this.price); 
    }
}
car1.increase();