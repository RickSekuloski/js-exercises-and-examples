//ES5 synatx for writing functions
const message = function(name) { 
    return "Hi there  " + name;
    //this line will never be executed
    console.log('Something');
}
let greeting = message('Andy');
console.log(greeting);

//ES6 arrow function syntax
const message1 = (name)=>{ 
    return "Hi there  " + name;
}
let greeting1 = message1('Jason');
console.log(greeting1);

//omit the brackets
const message2 = x => x + 1;
message2(1); // output: 2

//when returning an object literal
//onst message3 = () => { age: 1 } ;// message() returns undefined
const message3 = () => ({ age: 1 }) ;
let m = message3();
console.log(m);// massage() returns {age: 1}

//setTimeout
setTimeout(function () {
    console.log("Executed after 3 second");
  }, 3000);
//ES6 arrow syntax
setTimeout(() => console.log("Executed after 3 second"), 3000);

