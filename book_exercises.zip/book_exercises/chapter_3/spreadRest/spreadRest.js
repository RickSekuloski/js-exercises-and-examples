
//spread operator ...
const numbersArray = [1,2,3,6];

function avg(a,b,c,d){
    return (a + b + c + d)/ numbersArray.length;
}

//call the function
const result = avg(...numbersArray);
console.log(result);

//combine arrays
let oddNumArray = [1, 3, 5, 7, 9, 11];
let evenNumArray = [ 2, 4, 6, 8, 10, 12];
const mixedArray = [0, ...evenNumArray,...oddNumArray];
console.log(mixedArray);

//copy arrays
let oddNumArray1 = [1, 3, 5, 7, 9, 11];
//creating a copy not a reference
let oddArray = [...oddNumArray1];
//add new element in oddNumArray1
oddNumArray1.push(13);
//add new element in the oddArray
oddArray.push(15);
console.log(oddNumArray1);//[1, 3, 5, 7, 9, 11, 13]
console.log(oddArray);//[1, 3, 5, 7, 9, 11, 15]

//Spread in Object Literal ES2018 or ES9

let actorObj = {
    actorName: 'Rick',
    actorSurname:'Grimes',
    age: 48
}
let cloneActorObj = {...actorObj};
console.log(cloneActorObj);
//cloneActorObj.tvShows=true;


//rest
const actors = ["Jake", "Tom", "Andy", "Sara", "Claudia","Marina"]; 

const [maleFirst,maleSecond, maleThird,...femaleActors] = actors;
console.log(...femaleActors); // "Sara", 'Claudia','Mariane'
