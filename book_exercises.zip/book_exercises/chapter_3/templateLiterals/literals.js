//ES5
let name = 'Daryl';
let message = 'Hi there '+ name;
console.log(message);
//ES6
let name1 = 'Daryl';
let message1 = `Hi there ${name1}`;
console.log(message1);

//Expression Interpolation
//ES5
let x = 34;
let m = 4;
console.log('The sum of x + m is '+(x+m));//38
//ES6
let y = 34;
let z = 4;
console.log(`The sum of y + z is ${x+m}`);//38

//ES5 multi-line

let text = 'Hi there, \
my name is Rick,\
And I live in USA.';
console.log(text);

//ES6 multi-line
let text1 = `Hi there,
my name is Rick,
And I live in USA.`;
console.log(text1);

//nesting templates
const users = [
    {name: 'Rick Grimes'},
    {name: 'Andy Carol'},
    {name: 'Morgan Bana'}
];

const ulMarkup = `
<ul>
${users.map(user => `<li> ${user.name}</li>`
)}
</ul>
`;
console.log(ulMarkup);
//passing a function in a template literal
function allUsers(usersObj){
    return `
    ${usersObj.map(user=> `<li>${user.name}</li>`).join('\n')}
    `;
}
const ulMarkup1 = `
    <ul> ${allUsers(users)}</ul>
`;

const divEl = document.querySelector('#list');
divEl.innerHTML = ulMarkup1;

//startsWith & endsWith
const sampleText = "WWW-XXX-YYY-ZZZ";
console.log(sampleText.startsWith('WWW'));//true
console.log(sampleText.startsWith('XWW'));//false
console.log(sampleText.endsWith('ZZZ'));//true
console.log(sampleText.endsWith('YYY'));//false
