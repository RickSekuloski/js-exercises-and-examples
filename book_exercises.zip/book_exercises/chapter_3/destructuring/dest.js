//ES5 Objects
let actor = {
    firstName: 'Rick',
    lastName: 'Grimes',
    occupation: 'Actor',
    country: 'UK'
}

let firstName = actor.firstName;
let lastName = actor.lastName;
let occupation = actor.occupation;
let country = actor.country;

//ES6 destructuring
let actor1 = {
    firstName1: 'Rick',
    lastName1: 'Grimes',
    occupation1: 'Actor',
    country1: 'UK'
}
const {firstName1,lastName1,occupation1, country1} = actor1;
console.log(firstName1);
console.log(lastName1);
console.log(occupation1);
console.log(countryOfBirth1);

//nested data

let actor2 = {
    firstName1: 'Andrew',
    lastName1: 'Lincoln',
    occupation1: 'Actor',
    country1: 'UK',
    knownFor:{
        movies:{
            2020: '2020Old Vic in Camera: A Christmas Carol',
            2010: 'Made in Dagenham',
            2008: 'Play or Be Played'  
        },
        tvShows:{
            name: 'The Walking Dead'
        }
    }
}

//const {name} = actor2.knownFor.tvShow;
//rename the const {name}
const { name: tvShowName } = actor2.knownFor.tvShows;
//rename and pass default value
console.log(tvShowName);

//Destructuring Arrays ES6

const student = ['Rick','Grimes','12332323',false];

const [name,surname,sID,passed] = student;
console.log(name);
console.log(surname);
console.log(sID);
console.log(passed);

const person = ["Tom","Cruise",59];
const[firstName, lastName] = person;
console.log(firstName);
console.log(lastName);

//rest operator

const person1 = ["Tom","Cruise",59,'Top Gun','Oblivion','Mission Impossible'];
const[actorName, actorLastName, ...movies] = person1;
console.log(actorName);//Tom
console.log(actorLastName);//Cruise
console.log(movies);//['Top Gun','Oblivion','Mission Impossible']

