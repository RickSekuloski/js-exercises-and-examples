//ES5 Objects way of looping
//for-loop
let numArr = ['first','second','third','fourth'];

for (let i = 0; i < numArr.length; i++){
    console.log(numArr[i]); 
}
//first
//second
//third
//fourth

//ES6 for-of loop

for (const num of numArr){
    console.log(num); 
}

//ES6 iteration over Objects
const car = {
    maker: "Haval",
    color: "black",
    year : "2022",
}
for (const key of Object.keys(car)){
     const value = car[key]; 
     console.log(key,value);
}

//for-in
const car1 = {
    maker: "Haval",
    color: "black",
    year : "2022",
}
for (const key in car1){
     const value = car1[key]; 
     console.log(key,value);
}

//difference between for-in and for-of
let numbersArray = [1,2,3,4,5];
//for-in
for(let i in numbersArray){
    console.log(i);//0,1,2,3,4
}
//the for-in will return the kyes, or index positions


//for-of will return the values
for(let i of numbersArray){
    console.log(i);//1,2,3,4,5
}