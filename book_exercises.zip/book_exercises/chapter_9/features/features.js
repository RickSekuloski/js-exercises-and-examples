// array.prototype.flat()
const numArray = [0, 1, 2, [3, 4,5]];
console.log('Original array');
console.log(numArray);
//flat this array, the defalt level is 1
console.log('The flatten array')
console.log(numArray.flat());

//two levels nesting:
const numArray1 = [0, 1, 2, [3, 4, 5, [6,7]]];
console.log('Original array');
console.log(numArray1);
//flat this array, the defalt level is 1
console.log('The flatten array')
console.log(numArray1.flat(2));

//flatMap()
let arr1 = [1, 2, 3, 4];
let newArray2 = arr1.flatMap(x => [x * 2]);
// [2, 4, 6, 8];
console.log(newArray2);

//Object.fromEntries()
const entriesList = [
    ['name', 'Rick'],
    ['age', 33],
    ['occupation', 'developer']
  ];
  //let us create an object
  const newObj = Object.fromEntries(entriesList);
  console.log(newObj);

//trimStart()
const stringOne = '   Hello world!   ';

console.log(stringOne);
// expected output: "   Hello world!   ";

const stringTwo = stringOne.trimStart();
console.log(stringTwo);
// expected output: "Hello world!   ";

//stringEnd()
console.log(stringTwo.trimEnd());
// expected output: "Hello world!";


//function.prototype.toString()
function calculateSum(a, b) {
    return a + b;
  }
  
  console.log(calculateSum.toString());

// Symbol.prototype.description
const person = Symbol("Jason");
console.log(person.description);
// "Jason"
console.log(person.toString());
// "Symbol(Jason)"

const numbers  =[1, [2, 3, [4, [5, [6]]]] ];
console.log(numbers.flat())

function calculateSum(a, b) {
    //comment
    return a + b 
}
console.log(calculateSum.toString());