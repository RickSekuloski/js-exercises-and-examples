
let newContent = 'This text is coming from JavaScript';
document.body.innerHTML = "<h1> " + newContent + "</h1>"