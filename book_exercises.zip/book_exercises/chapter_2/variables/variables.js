//Before ES6 (ES2015) variables were declared like this
var name = 'Josh Morrison';
//ES6 (ES2015) variables are declared like this
let firstName = 'Josh';
let lastName = 'Morrison';

//Uncaught TypeError
const personAge = 33;
// personAge = 34;
//overwrite the values for let and var
var dob ='29.09.1992';
dob = '30.09.1992';

// let dogName = 'Bing';
// dogName = 'Bingo';
//case styles
//1) camelCase - recommended
let birthYear = '1988';
//2 PascalCase - recommended
let BirthYear = '1988';
//3)snake_case not recommended
let birth_year = '1988';

/*********** data types ***********/
/*********** Primitives ***********/
//1) string
let myText = 'Text';
let myText1 = "Text";

//2) number
let firstNum = 1;
let secondNum = 2;

//3) Boolean
let isTrue = true;
let isFalse = false;


//4) undefined
let noValue;

//5) null
let n = null;

//typeof operator
console.log(typeof myText);//
console.log(typeof firstNum);
console.log(typeof isTrue);
console.log(typeof noValue);
console.log(typeof n);
