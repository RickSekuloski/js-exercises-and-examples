const actor = {
    firstName: 'Cillian',
    lastName: 'Murphy',
    age: 45,
    show:'Peaky Blinders',
    getShow: function(){
        console.log(this.show) }
    }
actor.getShow();
//if we use this keyword in a function
 function getShow(){
    console.log(this) 
}
getShow();


const unboundGetShow = actor.getShow;
console.log(unboundGetShow());// undefined
const boundGetShow = unboundGetShow.bind(actor);
console.log(boundGetShow());// red