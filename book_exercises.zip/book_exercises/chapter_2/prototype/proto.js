//animal object
let animal = {
    eats: true,
    sleeps: true,

}
//dog object
let dog = {
    barks: true,
}


//We can set the dog prototype to be equal to animal
dog.__proto__ = animal;

console.log(dog.eats); // returns true
console.log(dog.sleeps); // returns true



//animal object
let animal1 = {
    eats: true,
    sleeps: true,
    isWalking(){
        return 'Animal is walking!';
    }
}
//dog object
let dog1 = {
    barks: true,
    __proto__:animal1
}

console.log(dog1.isWalking()); // returns Animal is walking

//Prototype Chain
//animal object
let animal2 = {
    eats: true,
    sleeps: true,
    isWalking(){
        return 'Animal is walking!';
    }
}
//dog object
let dog2 = {
    barks: true,
    __proto__:animal2
}
//labrador

let labrador = {
    color: 'golden',
    type: 'show',
    training: 'easy',
    __proto__:dog2
}

console.log(labrador.color); // returns golden
console.log(labrador.type); // returns show
console.log(labrador.training); // returns easy
console.log(labrador.barks); // returns true,
console.log(labrador.isWalking());// return Animal is walking 


//Prototype Write/delete operations work directly with the object.

let animal3 = {
    eats: true,
    sleeps: true,
    isWalking(){
        return 'Animal is walking!';
    }
}
//dog object
let dog3 = {
    barks: true,
    __proto__:animal3
}
dog3.isWalking = function(){
    return 'The dog is walking';
}

console.log(dog3.isWalking()); // returns The dog is walking

//Assignment of new values using setters
let user = {
    name: "Bill",
    surname: "Paxton",
  
    set firstName(name) {
      this.name = name;
    },
    set surName(surname){
        this.surname = surname;
    },
  
    get fullName() {
      return `${this.name} ${this.surname}`;
    }
  };
  
  let subscriber = {
    __proto__: user,
    isSubscriber: true,
  };
  
  console.log(subscriber.fullName);// Bill Paxton

  // we set/write new values using the setters
  subscriber.firstName = "Jason"; 
  subscriber.surName = "Mamoa"; 
  console.log(subscriber.fullName); // Jason Mamoa, state of subscriber modified
  console.log(user.fullName); // Bill Paxton, state of user protected


  //prototype inheritance with functions
  function Person(name,age) { 
      this.name = name;
      this.age = age;
    }
    Person.prototype.printDetails = function(){ 
        console.log("My name is: " + this.name + ', and I have: '+ this.age +' years');
    }

    const ana = new Person("Ana", 33);
    const sara = new Person("Sara",32);
    ana.printDetails();
    sara.printDetails();
