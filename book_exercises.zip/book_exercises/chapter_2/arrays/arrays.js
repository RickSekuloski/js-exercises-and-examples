let carBrands = ['Alfa Romeo','Audi','BMW', 'Bently', 'Buick','Cadilac'];
console.log(carBrands);
console.log(carBrands[0]);

//array methods:
//1) Get the length of an array
console.log(carBrands.length);
//2) Add new item at the end of the array
carBrands.push('GWM Haval');
console.log(carBrands);
//3) Add new item at the beginning of the array
carBrands.unshift('Kia');
console.log(carBrands);
//4) Remove an item from the end of the array
carBrands.pop();
console.log(carBrands);
//4) Remove an item from the beginning of the array
carBrands.shift();
console.log(carBrands);

//typeof
console.log(typeof(carBrands));