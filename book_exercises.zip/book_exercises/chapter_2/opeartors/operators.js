//Arithmetic Operators 
let a = 13;
let b = 4;
console.log(a+b);
console.log(a-b);
console.log(a*b);
console.log(a/b);
console.log(a%b);

//Increment and Decrement
let one = 10;
let two = 10;
let three = 10;
let four = 10;

console.log(one++);//10, incremenets the variable value by 1 after executing
//the current statement
console.log(two--);//10, decrements the variable value by 1 after executing
//the current statement
console.log(++three);//11,  Incremenets the variable value by 1 immediately
console.log(--four);//9 Decrements the variable value by 1 immediately

//Logical AND - && operator
let c = true;
let d = false;
let f = true;
let g = false;
console.log('Logical AND - &&');
console.log(c && d);// false
console.log(d && f);// false
console.log(d && g);// false
console.log(c && f);// true
console.log('Logical OR - ||');
//logical OR - ||
console.log(c || d);// true
console.log(d || f);// true
console.log(d || g);// false
console.log(c || f);// true

console.log(' Logical NOT ! operator');
console.log(!c);// false
console.log(!d);// true

//compund assignment

let i = 10;
// i +=10;
//equivalent as i = i + 10;
console.log(i+=10);//20
console.log(i-=10);//10
console.log(i*=10);//100
console.log(i/=10);//10
console.log(i%=10);//0

//Ternary operator ?:
let base = 5;
let myCondition = 10;
let result= (base > myCondition)? 'The Base is greater than the condition (10)' : ' The base is less than 10';
console.log(result);// The base is less than 10