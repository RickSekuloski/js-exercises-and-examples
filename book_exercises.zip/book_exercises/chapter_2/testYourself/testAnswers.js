/*
1)	Which of the following is not a Primitive data type?
a)	boolean
b)	number
c)	string
d)	Object
e)	symbol
f)	null

********* Answer ***********************************
1)
d)Object
--------------------------------------------------//
2)	Which of the following is not a Primitive Data type?
a)	boolean
b)	number
c)	string
d)	undefined
e)	symbol
f)	Array
g)	null

********* Answer ***********************************
2)
f)Array
--------------------------------------------------//

3)	What is the correct way of declaring an Object (there can be more than one correct answer)?
a)	const person: {age: '34',}
b)	const person: {age: 34}
c)	const person= {age = 34}
d)	const person= {age: '34',}
e)	const person: {age = '34',}
f)	const person= {age: '34',}

********* Answer ***********************************
3)
d)const person= {age: '34',}
f)const person= {age: '34',}
--------------------------------------------------//

4)What is the output from the following code?
const firstObj = { color: 'green', shape: 'square'};
console.log('The result is' + ' ' + firstObj.shape)
a)	square
b)	The result is firstObj.shape
c)	The result issquare
d)	The result is square

********* Answer ***********************************
4)
d)	The result is square
--------------------------------------------------//

5)	What is the output from the following code?
const firstObj = {age: 30};
const secondObj = {age: 30};
console.log(firstObj === secondObj);

a)	false
b)	undefined
c)	true
d)	null
********* Answer ***********************************
5)
d)	false
--------------------------------------------------//
6)	What is the output from the following code?
const numbersArray = [1,2,3,4,5]; 
numbersArray.unshift(0);
console.log(numbersArray);

********* Answer ***********************************
6)
c) [0, 1, 2, 3, 4, 5]
--------------------------------------------------//

7)	What will be the output from the following code?
const firstObj = {age: 30}; 
const secondObj = Object.assign({}, firstObj);
console.log(secondObj);

********* Answer ***********************************
7)
{age: 30}
--------------------------------------------------//
8)	Can you find the invalid variable names (there are four)?

a)	let camelCase = "lowercase word, then uppercase";
b)	var 2fast2catch = "bold claim";
c)	var dinner2Go = "pizza";
d)	const total% = 78;
e)	const I_AM_HUNGRY = true;
f)	let _Hello_ = 'what a nice greeting'
g)	const class = "easy";
h)	let $_$ = "money eyes";
i)	let function = false;
********* Answer ***********************************
8)
b)var 2fast2catch = "bold claim";
d)const total% = 78;
g)const class = "easy";
i)let function = false;
--------------------------------------------------//
9)	What will be the output from the following code?
var message = "Hello";
message = "World";
if(message){
    var message = "Hello World";
}
console.log(message);
a)	Hello
b)	Hello
World
c)	Hello World
d)	World
********* Answer ***********************************
9)
c) Hello World
--------------------------------------------------//
10)	 What will be the output from the following code?
if(message){
    var message = "Hello World";
}
console.log(message);

********* Answer ***********************************
10)
b)	undefined
--------------------------------------------------//

11)	What will be the output from the following code?
let number1 = 1;

if(true) {
let number1 = 2;
}
number1 = 3;
console.log(number1);
 
a)	1
b)	2
c)	3
********* Answer ***********************************
11)
b)	3
--------------------------------------------------//
12)	What will be the output from the following code?
console.log(number2);
const number2 = 31;
a)	31
b)	ReferrenceError
c)	undefined
********* Answer ***********************************
12)
b)	ReferrenceError
--------------------------------------------------//

13)	Given the following array:
let mixedArray = [1, "two", 3, "4", "five",true]
Write what it will be printed in the console for each of these examples:
a)	console.log(mixedArray[0]);
b)	console.log(mixedArray[0] + mixedArray[1]);
c)	console.log(mixedArray[2] + mixedArray[3]);
********* Answer ***********************************
13)
a) 1
b) 1two
c) 34
--------------------------------------------------//

14)	What is a class?
********* Answer ***********************************
c.	Syntactic sugar to perform prototypal inheritance

--------------------------------------------------//
15)	Which one is correct when we want to declare a class?
********* Answer ***********************************
b.	const person = class Person {…}
c.	class Person {…}

--------------------------------------------------//
16)	Which is a static method?
********* Answer ***********************************
c.	A method that can be accessed only by the class itself
--------------------------------------------------//
17)	What will be the output?
class Person { 
    constructor(name,age){
        this.name = name;
        this.age = age; 
   }
}
class Employee extends Person {    
constructor(employeeID){
this.employeeID = employeeID;
} 
}
const james = new Employee('1224343545'); 
console.log(my.james);
********* Answer ***********************************

b.	ReferenceError: Must call super constructor in derived class before accessing 'this'
--------------------------------------------------//
18)	Calculate the average number of weeks in human lifetime
const daysPerYear = 365;
const daysPerWeek = 7;
const years = 94;

********* Answer ***********************************
const totalWeeksInALifetime = (daysPerYear / daysPerWeek) * years;
// 4901
--------------------------------------------------//
19)	What will be the output from the conditional statement if, else if and else?
let a = 7
if (a > 7) {
  console.log('greater than 7');
} else if (a < 7) {
    console.log('smaller than 7');
} else {
    console.log('seven');
}
Result: ‘Seven’;

--------------------------------------------------//
20)	What is the value of variable ‘n’ after execution of the following code?
 Moe
--------------------------------------------------//
21)	Write simple function called myMessage that will take only one parameter and will return ‘Hello <parameter>!’
Example myMessage(‘Tom’) should return ‘Hello Tom!’

function myMessage(name){
    return 'Hello ' + name;
}
const greeting = myMessage('Tom');
console.log(greeting);
--------------------------------------------------//
22)	String Concatenation, what is the value of ‘y’ after the execution of the following function
function stringConcat(name) {
    return name + ' and ' + name;
  }
  
  let y = stringConcat('James');
  console.log(y);

e)	James and James


--------------------------------------------------//
23)	 Write a function that will determine whether a number that is passed as a parameter is decimal or not. If the number is decimal return this ‘This number is decimal <number>’, otherwise rerun ‘This number is not decimal.
Hint: There are many ways we can do this but you can use the Math.floor function for this or you can use modulo
Using the Math.floor function:
function ifInteger(number){
    if(number == Math.floor(number)){
        console.log('Integer')
    }
    else{
        console.log('Decimal');
    }
}

let number = ifInteger(20.5);
console.log(number);//Decimal
let number1 = ifInteger(17);
console.log(number1);//Integer

Using modulo operator:
function ifInteger(number){
    if(number % 1 == 0){
        console.log('Integer')
    }
    else{
        console.log('Decimal');
    }
}

let number = ifInteger(20.5);
console.log(number);//Decimal
let number1 = ifInteger(17);
console.log(number1);//Integer
*/
let originalString = 'evil';
let newString = '';
function reverseString(text) {
    console.log(text);
    if (text === '') {
      return ''
    }

    return reverseString(text.substr(1)) + text.charAt(0);
}
let result = reverseString(originalString);
console.log(result);
