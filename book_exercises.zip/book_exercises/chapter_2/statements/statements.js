//If statement

let userAge = prompt('How old are you?');
console.log(userAge);
let theAge = parseInt(userAge);
console.log(theAge);

//-----if statement -------//
if(theAge < 25){
    console.log('You belong in the Youth Age Category');
}


//----- if-else statement -------//

if(theAge < 25){
    console.log('You belong in the Youth Age Category');
}
else{
    console.log('You belong in the Adult Age Category')
}


//----- if-else-if-else ladder -------//

if(theAge <= 14){
    console.log('You belong in the Children Category');
}
else if(theAge >=15 && theAge <=24){
    console.log('You belong in the Youth Category');
}
else if(theAge >=25 && theAge <=64){
    console.log('You belong in the Adults Category');
}
else{
    console.log('You belong in the Seniors Category because you are 65 and over');
}

let dayOfWeek = parseInt (prompt( "Enter an integer between 1 and 7" ));
switch (dayOfWeek){
    case 1: 
        console.log('Today is Monday');
        break;
    case 2: 
        console.log('Today is Tuesday');
        break;
    case 3: 
        console.log('Today is Wednesday');
        break;
    case 4: 
        console.log('Today is Thursday');
        break;
    case 5: 
        console.log('Today is Friday');
        break;
    case 6: 
        console.log('Today is Saturday');
        break;
    case 7: 
        console.log('Today is Sunday');
        break;
    default: 
        console.log('Please enter a number between 1 and 7');
}