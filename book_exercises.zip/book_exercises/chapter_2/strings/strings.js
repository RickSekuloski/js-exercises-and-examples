//JavaScript strings

//.length()
const str = 'This is a string';
console.log(str.length);

//.trim()
const str1 = '    String contains white spaces.    ';
console.log(str1.trim());//'String contains white spaces.'

//includes()
const str2 = 'My name is Saul Goodman';
const searchTerm1 = 'Good';
const searchTerm2 = 'Man';

console.log(str2.includes(searchTerm1));//true
console.log(str2.includes(searchTerm2));//false

//indexOf()
const str3 = 'My name is Saul Goodman';
const searchTerm3 = 'Good';
const searchTerm4 = 'Man';

console.log(str3.indexOf(searchTerm3));//16
console.log(str3.indexOf(searchTerm4));//-1


//toUpperCase()
const str4 = 'My name is Saul Goodman';
console.log(str4.toUpperCase());//MY NAME IS SAUL GOODMAN

//toLowerCase()
const str5 = 'My name is Saul Goodman';
console.log(str5.toLowerCase());//my name is saul goodman

//replace()
const str6 = 'Hi there!';
const strPattern = 'there';
const replaceString = 'folks';
console.log(str6.replace(strPattern,replaceString));//'Hi folks'

//slice()
const str7 = 'My name is Rick Grimes';
console.log(str7.slice(11));//Rick Grimes
console.log(str7.slice(11, 15));//Rick

//split()
const str8 = 'My name is Rick Grimes';
const stringArray = str8.split(' ');
console.log(stringArray);

//repeat()
const str9 = 'Repeat!';
console.log(str9.repeat(4));

//match
const str10 = 'This is the best guide. I Love It!';
const regex = /[A-Z]/g;
const matches = str10.match(regex);
console.log(matches);//['T', 'I', 'L', 'I']

//charAt()
const str11 = 'Rick Grimes';
console.log(str11.charAt(0));//R
console.log(str11.charAt(1));//i
console.log(str11.charAt(2));//c
console.log(str11.charAt(3));//k
console.log(str11.charAt(5));//G

//charCodeAt()
const str12 = 'Rick Grimes';
console.log(str12.charCodeAt(0));//82
console.log(str12.charCodeAt(1));//105
