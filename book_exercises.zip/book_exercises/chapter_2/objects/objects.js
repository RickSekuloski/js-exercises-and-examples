//Objects


/*********** Object ***********/
let person = {
    name: 'Jason',
    age: 33,
    isMarried: true
}
let person1 = {
    name: 'Jason',
    age: 33,
    isMarried: true,
    working: function(){
        console.log('As a programmer and web dev');
    }
}
//empty object using the new keyword
let empObj = new Object();
//empty object using the object literal syntax
let emObj = {};

//trailing comma at the end of last key-value pair is ok
let person2 = { 
    firstName: "Thomas", //FirstName Property
    lastName: "Jefferson",//lastName Property
    isDead: false, // trailing comma is ok
};

 
/*********** Adding new properties to an Object ***********/
//add new properties
emObj.name = 'Rick';
console.log(emObj);

/*********** Accessing the properties from an Object ***********/
//using the dot notation
console.log(person2.firstName); // Thomas
console.log(person2.lastName); // Jefferson
console.log(person2.isDead); // false

//using square bracktes
console.log(person2['firstName']); // Thomas
console.log(person2['lastName']); // Jefferson
console.log(person2['isDead']); // false

/*********** Primitive values vs Reference Values ***********/
let dogName = 'Flash';
let dogAge = 2;
let dogObj = {
    dogName: 'Flash',
    dogAge: 2,
}
/*********** Copying Objects Reference Values ***********/
//create firstObject with two key/value pairs
let firstObj = {
    color: 'green',
    shape: 'square',
}
//Create new variable secondObj and initilize with the firstObj;
let secondObj = firstObj;
//add new property 'border; to the firstObj using dot notation
firstObj.border ='solid';

console.log(firstObj);
console.log(secondObj)

console.log(firstObj == secondObj);
console.log(firstObj === secondObj);

//let us create two objects with same properties and compare them
let thirdObj = {
    width: '40px',
    height: '40px',
}
let fourthObj = {
    width: '40px',
    height: '40px',
}
console.log(thirdObj == fourthObj);
console.log(thirdObj === fourthObj);


//Primitive data type
let numberOne = 90;
let numberTwo = numberOne;
numberOne = numberOne + 10;
console.log(numberOne);
console.log(numberTwo);

//Cloning objects

let fifthObj = {
    width: '40px',
    height: '40px',
}
//creating clone or exact copy of the fifthObj
const sixthObj = Object.assign({}, fifthObj);
fifthObj.color ='yellow';
console.log(fifthObj);
console.log(sixthObj);