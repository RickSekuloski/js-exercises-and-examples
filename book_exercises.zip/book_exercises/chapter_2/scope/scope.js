//JavaScript scope

//global variable
let n = 4;
function calc() {
    //local variable
    let m = 5;
    console.log(n * m);
}

calc();
//console.log(n + m); 

// block-scoped concept
// global variable
let a = 6;

function multiply() {

    // local variable
    let b = 9;
    console.log(a + b);

    if (b == 9) {
        // block-scoped variable
        let c = 5;
        console.log(a + b + c);//20
    }
    // variable c cannot be accessed outside the 
    //block where is defined
    console.log(a + ' ' + b + ' ' + c);
}

multiply();
