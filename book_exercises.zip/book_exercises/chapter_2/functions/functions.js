//JS functions

function message(){
    console.log('Hello');
}
message();

function personalMessage(personName){
    console.log('Hello ' + personName);
}
personalMessage('Novak');

//passed by value
let age = 34;
function personalMessage1(personAge){
    personAge = personAge-10;
    console.log('The Person age is: ' + personAge);
}
personalMessage1(age);
console.log(age);
//passed by reference
let carBrands = ['Alfa Romeo','Audi','BMW', 'Bently', 'Buick','Cadilac'];
console.log('1) Original Car Brand Array');
console.log(carBrands);
function addCar(carBrands){
    carBrands.push('GWM Haval');
    console.log('2) Array with new element added in the function');
    console.log(carBrands);
}

addCar(carBrands);
console.log('3) Print the array after the function is finished');
console.log(carBrands);

//function expression

const myMessage = function aMessage(messageBody){
    console.log(messageBody);
}
myMessage('Another way to declare a function is by using a function expression');
//anonymous function
const myMessage1 = function (messageBody){
    console.log(messageBody);
}
myMessage1('Anonymous function');

//arrow functions
const myMessage2 = (messageBody) =>{
    console.log(messageBody);
}
myMessage2('Another way to declare a function is by using an arrow function expression');
