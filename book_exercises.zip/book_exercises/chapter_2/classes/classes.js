//JavaScript Classes
class Employee{

    constructor(id, firstName, lastName){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    } 
    printDetails(){
        let details = 'ID: ' + this.id + '<br>';
        details += 'Name: '+ this.firstName+ '<br>';
        details += 'Last name: '+ this.lastName + '<br>';
        return details;
    }
}
let firstEmployee = new Employee (123456234,'Johnny', 'Depp');
let secondEmployee = new Employee (123456234,'Amber', 'Heard');

document.write ('<h2> First Employee details: </h2>');
const johnny = firstEmployee.printDetails();
document.write(johnny);
document.write ('<h2> Second Employee details: </h2>');
const amber = secondEmployee.printDetails();
document.write(amber);


//class expression

let Employee1 = class{
    constructor(id, firstName, lastName){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    printDetails(){
        let details = 'ID: ' + this.id + '<br>';
        details += 'Name: '+ this.firstName+ '<br>';
        details += 'Last name: '+ this.lastName + '<br>';
        return details;
    }
}
document.write ('<h2> Define Classes via expression forms </h2>');
var emp1 = new Employee( 1233342334 , "Nicola" , "Tesla" ); 
document.write(emp1.printDetails());

//static methods
document.write ('<h2> Static methods </h2>');
class Person { 
    constructor(name,age){
    this.name = name;
    this.age = age;
    }
    hello(){
        return `Hi, my name is ${this.name} 
        and I am ${this.age} years old`;
        }
    static goodbye(){
        return("See you soon!"); 
    }
}

const kate = new Person("Kate",19);
document.write(kate.hello());
// document.write(kate.goodbye());
document.write(Person.goodbye());
// Hello, my name is Alberto and I am 26 years old alberto.farewell();

//setters and getters methods
document.write ('<h2> Setters and Getters  </h2>');
class Person1 { 
    constructor(name,age) {
        this.name = name;
        this.age = age; 
        this.nickname = "";
    }
    set nicknames(value){
        this.nickname = value;
    }
    get nicknames(){
        return `Nickname is ${this.nickname}`;
    }
}
const camila = new Person1("Camila",33);
// we call the setter
camila.nicknames = "Cami"; // "Cami"
// then we call the getter
document.write(camila.nicknames);
// "Nickname is Cami"

document.write('<h2>Class Inheritance</h2>');
//Class Inheritance - extends
class Person2 { 
    constructor(name,surName,age,dob,country,uID,zipCode) {
        this.name = name;
        this.surName = surName; 
        this.age = age; 
        this.dob = dob;
        this.country = country;
        this.uID = uID;
        this.zipCode = zipCode;
    }
    printDetails(){
        return `Hello, my name is ${this.name}
        and I am ${this.age} years old
        from ${this.country}`;
    }
}
class Student extends Person2{
    constructor(name,surName,age,dob,country,uID,zipCode,sID,uni,major) {
        super(name,surName,age,dob,country,uID,zipCode);
        this.sID = sID;
        this.uni = uni;
        this.major = major;
    }
    printDetails(){
        return `Hello, my name is ${this.name},
        and I am styding at ${this.uni} university
         and my goal is to become an  ${this.major}`;
    }
}
document.write('<h2>Chris is an instance of a Person class</h2>');
const chris = new Person2('Chris','Hemsworth',39,'14.02.1983','Australia','A12D34X56',3000);

document.write(chris.printDetails());
document.write('<h2>Liam is an instance of a Student class which inherits from Person class</h2>');
const liam = new Student('Liam','Hemsworth',23,'14.02.1990','Australia','A12D34X56',3000,'21342343','Monash','engineer');
document.write(liam.printDetails());
