
//if statement
let num = 4;
if(num == 4){
    console.log('The value in the let num variable is: ' + num);
    var numTwo = 10;
    console.log('The value of the var numTwo is: '+ numTwo);
}
//let see if we can use the value of numTwo outside the if block
console.log('Print the value of var numTwo outside the block where is defined: '+ numTwo );

//function scope
function testingScope(){
    var textVar = "Text inside a function"; 
    console.log(textVar);
}
testingScope();
//let us see if we can use the value of the varibale textVar outiside the function
//console.log(textVar);


//let are block-scoped
// using `let`
let textOne = 'Global Variable';
if (textOne === 'Global Variable') {
    let textOne = 'New Value';
    console.log('1) '+ textOne);
    if(textOne === 'New Value'){
        console.log('2) '+ textOne);
    }
}
console.log(textOne);//expected output: Global Variable

//const variables are block scoped
const sampleText = 'This is a const variable';
// sampleText = 'This should not work!';
// const sampleText1;//should not work

//const objects

const car = {
    color: 'black',
    model: 'Toyota Rav4',
    isHibrid: false
}
console.log(car);
//we can edit the property values
car.isHibrid = true;
//we can add new key/value pairs
car.expensive = true;
car.availability = 'Not Available!';
console.log(car);

//we can freeze the object, and will no longer accept changes
const car1 = {
    color: 'black',
    model: 'Toyota Rav4',
    isHibrid: false
}
Object.freeze(car1);
//we can't edit the property values
car1.isHibrid = true;
//we can't add new key/value pairs
car1.expensive = true;
car1.availability = 'Not Available!';
console.log(car1);

//temporal dead-zone

//console log a variable newNumber before it is declared
console.log(newNumber);
var newNumber = 10;// Output: undefined

//this will not work with let variables
console.log(newNumber1);
let newNumber1 = 20;
