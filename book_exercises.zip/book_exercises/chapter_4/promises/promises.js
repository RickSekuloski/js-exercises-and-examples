//JS promises

let promiseOb = new Promise((resolve, reject) => { 
    resolve('The promise is resolved');
});
promiseOb.then(data => console.log(data));

//resolved promise
let promise = new Promise(function(resolve, reject) {
    resolve('Resolved Promise');
});
   
promise
    .then(function(data) {
       //success handler function is invoked
        console.log(data);
    }, function(errorMsg) {
        console.log(errorMsg);
    });

//rejected promise
let promise1 = new Promise(function(resolve, reject) {
    reject('The Promise Rejected')
})
   
promise1
    .then(function(data) {
        console.log(data);
    }, function(errorMsg) {
       //error handler function is invoked
        console.log(errorMsg);
    })

//handling rejected promises using the .catch()
var promise2 = new Promise(function(resolve, reject) {
    reject('The Promise Rejected')
})
   
promise2
    .then(function(data) {
        console.log(data);
    })
    .catch(function(errorMsg) {
        console.log(errorMsg);
    });