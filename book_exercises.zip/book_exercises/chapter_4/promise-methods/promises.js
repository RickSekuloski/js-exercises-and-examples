//Promise.all()

const promise1 = new Promise((resolve,reject) => { 
    setTimeout(resolve, 1000, 'First promise');
});
const promise2 = new Promise((resolve,reject) => {
    setTimeout(resolve, 2000, 'Second Promise'); 
});
const promise3 = Promise.resolve('Third Promise');

Promise.all([promise1, promise2, promise3]).then((values) => {
    console.log(values);
  });

  //Promise.race
  const promise4 = new Promise((resolve, reject) => {
    setTimeout(resolve, 2000, 'Promise 4');
  });
  
  const promise5 = new Promise((resolve, reject) => {
    setTimeout(resolve, 1200, 'Promise 5');
  });
  
  Promise.race([promise4, promise5]).then((value) => {
    console.log(value);
    // Both resolve, but promise5 is faster than promise 4
  });
  // expected output: "Promise 5"


  const promise1 = new Promise((resolve, reject) => {
    setTimeout(reject, 2000, 'Error');
  });
  promise1.then((data) => {
      console.log(data);
    }).then((data) => {
      console.log(data);
      }).catch(() => {
          console.log('Error');
        }).then((data) => {
            console.log('Error') 
        });