function * howGeneratorWorks() { 
  console.log('First value');
  yield 'Second Value';
  console.log('Third value');  
  yield 'Final value';
}
const genObj = howGeneratorWorks(); 
console.log(genObj.next().value); 
//First Value
//Second value
console.log(genObj.next().value); 
//Third value
console.log(genObj.next().value);
//Final Value


//loop over arrays using the generators
let cars = ['Alfa Romeo','Buick','Cadillac','Dodge','Ford','Honda','Infiniti'];

//looping generator
function* loopCars(cars){
  for(const car of cars){
    yield `The car brand is ${car}`;
  }
}

const carGenerator = loopCars(cars);

console.log(carGenerator.next());
//{value: 'The car brand is Alfa Romeo', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Buick', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Cadillac', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Dodge', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Ford', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Honda', done: false}
console.log(carGenerator.next());
//{value: 'The car brand is Infiniti', done: false}
console.log(carGenerator.next());
//{value: undefined, done: true}


//catching errors using the .throw()

function* simpleGen(){ 
  try {
    yield "First value";
    yield "Second";
    yield "Third";
    yield "Fourth";
  }
   catch(err) {
     console.log("Error: " + err );
    }
  }

const simpleG = simpleGen();
console.log(simpleG.next());//First
console.log(simpleG.next());//Second
simpleG.throw("An error occured");
console.log(simpleG.next());//Third
console.log(simpleG.next());//Fourth

