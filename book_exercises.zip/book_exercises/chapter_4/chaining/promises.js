//Promise chaining
let promiseOb = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve(2);
    }, 3000);
});

//consume the promise
promiseOb.then((data) => {
    console.log(data);
    return data * 2;
}).then((newData)=>{
    console.log(newData);
    return newData * 4;
});

//Returning a new promise from .then() method
let promiseOb1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('First');
    }, 3000);
});

promiseOb1.then((dataFirst) => {
    console.log(dataFirst);
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(dataFirst + ', Second');
        }, 2000);
    });
}).then((dataSecond) => {
    console.log(dataSecond);
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(dataSecond + ', Third!');
        }, 2000);
    });
}).then(result => console.log(result));


