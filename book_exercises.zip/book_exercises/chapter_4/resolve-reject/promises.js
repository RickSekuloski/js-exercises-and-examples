//Promise.resolve()
Promise.resolve('Success').then(function(value) {
    console.log(value); // "Success"
  }, function(value) {
    // will not be called
  });

//Promise.reject()
Promise.reject(new Error('fail')).then(function() {
  // not called
}, function(error) {
  console.error(error);
});
