
const theUsers = document.getElementById('theUsers');
const jsonUsers = fetch("https://jsonplaceholder.typicode.com/users");
//console.log(jsonUsers);
jsonUsers.then(users => {
    //console.log(users);
    return users.json();
  }).then(users =>{
      //console.log(users);
      theUsers.innerHTML =  usersList(users);
    });
function usersList(users) {
    const names = users.map(user => 
        `<li> ${user.name} - <span style='color:red'>username: ${user.username}</span></li>`).join("\n");
    return `<ul>${names}</ul>`
    }