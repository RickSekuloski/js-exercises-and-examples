// Async itearation

let numArray  = [1,2,3,4];

async function myArray(){
    for await(const item of numArray){
        console.log(item);
    }
}
myArray();

//Promise.prototype.finally()
const promiseOne = new Promise((resolve,reject) => {
     resolve('Settled');
});
promiseOne
.then((data) => { 
    console.log(data);
}).catch((err) => {
console.log('there was an error',err);
}).finally(()=> {
console.log('Finally Completed!'); })

//finally 
const promiseTwo = new Promise((resolve,reject) => {
    resolve('Settled');
});
promiseTwo
.then((data) => { 
   console.log(data);
   return data;
}).finally(()=> {
console.log('Finally Completed!');
}).then(data =>{
    console.log(data);
});

//spread/rest ES6 syntax

const numArray1 = [1,2,3,4];
const numArray2 = [6,7,8,9];
const numbersArray = [...numArray1, 5, ...numArray2];
console.log(numbersArray);

// ES9
let firstObj = {
    one:1,
    two:2,
    three:3,
    four:4,
}
//We can get the rest of the values in theRest variable.
let { one, two, ...theRest } = firstObj;
console.log(one);//1
console.log(two);//2
console.log(theRest);//{three:3, four:4}

//cloning an object
let firstObjClone = {...firstObj};
console.log(firstObjClone);//{

