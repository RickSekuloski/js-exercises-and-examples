//padStart

let myString = 'Rick Grimes';
console.log(myString);
console.log(myString.padStart(13));

//padEnd

let myString1 = 'Rick';
console.log(myString1);
console.log(myString1.padEnd(13));

//passing strings and numbers as parameters

let emerStr = '11';
console.log(emerStr.padStart(3,9));//911

let myString2 = '10';
console.log(myString2.padEnd(3,1));//101

//Object.entries() & Object.values()
const car = {
    brand: 'BMW',
    build: 2023,
    engine: '3L Turbo',
    color: 'Yellow'
}
//Before ES8 we would access its values using the keys 
let carKeys = Object.keys(car);
console.log(carKeys);

//ES8 object.values
let carValues = Object.values(car);
console.log(carValues);

//ES8 object.entries
let totalCar = Object.entries(car);
console.log(totalCar);

//ES8 Object.getOwnPropertyDescriptors()
console.log(Object.getOwnPropertyDescriptors(car));

//trailing commas
const carOb = {
    brand: 'Audi',
    transmission: 'auto',
}
//async function
async function myFun() {
    return 'Hi';
}
//consume the promise
const res = myFun();
res.then(data =>{
    console.log(data);//Hi
});

//await
async function myFn1() {

    let promise = new Promise((resolve, reject) => {
      setTimeout(() => 
      resolve("Finished after 2 Seconds!"), 2000)
    });
  
    let data = await promise; // wait until the promise resolves (*)
  
    console.log(data);
  }
  
  myFn1();

  //error handling
  async function myFn2() {
    await Promise.reject(new Error("Error!"));
  }

  async function myFn3() {

    try {
      let response = await fetch('https://jsonplaceholder.typicode.com/users/1');
      let data = await response.json();
      console.log(data.name)
    } catch(err) {
      // catches errors both in fetch and response.json
      alert(err);
    }
  }
 myFn3();

 async function myFn4() {
      let response = await fetch('https://jsonplaceholder.typicode.com/users/1');
      let data = await response.json();
      console.log(data.name)
  }
 myFn4().catch(alert);

