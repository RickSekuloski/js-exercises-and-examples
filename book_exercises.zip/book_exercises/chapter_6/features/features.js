//includes

let numArray = [1,2,3,4,5];

console.log(numArray.includes(4));//true
console.log(numArray.includes(6));//false

//find element 2 starting from index 1
console.log(numArray.includes(2, 1));

//exponential
console.log(Math.pow(2,2));

//new ES7
console.log(2**2);//4
console.log(2**3);//8

